# CivicLens — Nigerian Civic Verification & Public Safety Starter

A deployable starter application for public record lookup, citizen reporting, report tracking, and an authenticated demonstration admin workspace.

**Important:** This is an independent prototype, not an official government service. It is not endorsed by or connected to NAFDAC, EFCC, CAC, the Police, or any other agency. The included verification records are fictional demo data. Reports submitted to this app are stored in this deployment only and are not sent to government agencies.

## What works in this starter

- Responsive public landing page.
- Swappable data-provider architecture: all fictional verification fixtures and seeded demo cases are isolated in `src/providers/demo-provider.js`.
- `DATA_PROVIDER=demo` enables the client-presentation dataset; `DATA_PROVIDER=live` disables demo seeding and hides old demo records from live verification and case views.
- A safe live adapter template in `src/providers/live-provider.js`; it never pretends a government source was queried. Implement agency-specific APIs there only after authorization.
- Backward-compatible database migration adds a demo flag to existing report tables.
- Citizen report submission with generated reference numbers.
- Public status tracking by reference number.
- Password-protected admin workspace using an HTTP-only session cookie.
- Admin report list and status updates.
- Basic audit events, rate limiting, security headers, and persistent SQLite storage.
- Docker deployment with persistent volume.

## Deploy quickly on a VPS with Docker Compose

1. Upload and extract this project on your server.
2. In the project directory, create the environment file:

   ```bash
   cp .env.example .env
   ```

3. Edit `.env` and set a strong admin password and a unique secret of at least 32 characters:

   ```bash
   nano .env
   ```

   Generate a secret with `openssl rand -hex 32`. Set `COOKIE_SECURE=true` when the app is served behind HTTPS. Do not expose the app publicly over plain HTTP with real data.

4. Start the app:

   ```bash
   docker compose up -d --build
   docker compose logs -f civiclens
   ```

5. Open `http://YOUR_SERVER_IP:3000` for a temporary test. For a real public deployment, put it behind HTTPS using your reverse proxy / Coolify and point a domain to it.

6. The admin console is linked in the footer as **Agency sign-in**. Credentials are `ADMIN_USERNAME` and `ADMIN_PASSWORD` from `.env`.

## Deploy with Coolify

- Create a new application from the uploaded Git repository or Dockerfile.
- Set the build pack to Dockerfile.
- Configure the environment variables from `.env.example` in Coolify. Do not commit `.env` to Git.
- Expose container port `3000`.
- Attach persistent storage at `/data`.
- Add a domain and enable HTTPS.
- Set `COOKIE_SECURE=true` after HTTPS is configured.
- Deploy and check `/api/health`.

## Run locally without Docker

Requires Node.js 20 or newer and native build tools for `better-sqlite3`.

```bash
cp .env.example .env
# Edit .env before using admin login.
npm install
npm start
```

The app uses `/data/civiclens.db` by default. The selected data provider is controlled by `DATA_PROVIDER` (`demo` or `live`). For local development, set `DATA_DIR=./data` in `.env` if you want the database stored in the project folder.

## Demo data is isolated and switchable

**The file to treat as demo-only is `src/providers/demo-provider.js`.** It contains the fictional verification records and the seeded sample reports. The rest of the application calls a provider interface, so the public UI and core workflows do not need to be rewritten when the data source changes.

For client demonstrations, use:

```env
DATA_PROVIDER=demo
```

For a launch-preparation environment, switch to:

```env
DATA_PROVIDER=live
```

Then rebuild/restart the app:

```bash
docker compose up -d --build
```

In live mode, the demo provider is not loaded, no new sample cases are seeded, and demo verification/report references from an older database are hidden from live views. The existing demo rows remain marked `demo=1` in the database for safe rollback; they are not automatically deleted. If you later need to purge them, back up the database first and use a reviewed migration or cleanup script.

`src/providers/live-provider.js` is the separate adapter to implement for approved government/regulatory APIs. It currently fails closed and returns `SOURCE_UNAVAILABLE`, because no official API contract or credentials have been supplied. Setting `VERIFICATION_API_URL` and `VERIFICATION_API_TOKEN` alone does **not** connect a real source. Implement and test the agency-specific request/response mapping in that file first. Report intake also remains local to this app until an authorized case-management/referral integration is implemented.

**Important:** Do not delete `demo-provider.js` while `DATA_PROVIDER=demo` is configured. For the real launch, set `DATA_PROVIDER=live` and implement the live adapter; the app selects the provider from the environment.

## Demo data for a test run

On startup, CivicLens automatically inserts sample records using `INSERT OR IGNORE`, so it is safe to restart the application. All sample records are fictional and explicitly marked as demo data. They are not real NAFDAC, CAC, professional, permit, police, EFCC, or other government records, and seeded reports are not sent to any agency.

### Verification IDs to try

| Identifier | Scenario shown | Purpose |
|---|---|---|
| `CL-DEMO-NAFDAC-001` | Demo · VERIFIED | Test a positive-match presentation |
| `CL-DEMO-NAFDAC-002` | Demo · EXPIRED | Test an expired-record scenario |
| `CL-DEMO-NAFDAC-003` | Demo · INVALID | Test an invalid-identifier scenario |
| `CL-DEMO-CAC-001` | Demo · VERIFIED | Test a business-record scenario |
| `CL-DEMO-PRO-001` | Demo · UNCONFIRMED | Test a record requiring more checks |
| `CL-DEMO-PERMIT-001` | Demo · EXPIRED | Test a permit scenario |
| `CL-DEMO-NOTICE-001` | Demo · VERIFIED | Test a public-notice scenario |
| `CL-DEMO-NAFDAC-004` | Demo · UNCONFIRMED | Test a cautious unconfirmed result |

The status after `Demo ·` is a **fictional scenario outcome**, not an official registry determination. Unknown IDs should return `UNCONFIRMED`, not “fake”.

### Seeded report references to try

- `CL-DEMO-2026-001` — product-label concern, Received.
- `CL-DEMO-2026-002` — fictional investment-message report, Under review.
- `CL-DEMO-2026-003` — fictional recruitment-page impersonation, Referred.
- `CL-DEMO-2026-004` — streetlight safety report, Action required.
- `CL-DEMO-2026-005` — packaged-drink label concern, Under review.
- `CL-DEMO-2026-006` — suspicious SMS report, Resolved.
- `CL-DEMO-2026-007` — simulated cross-team referral, Closed.
- `CL-DEMO-2026-008` — impersonation-call report, Received.

Use the references in the public **Track a report** form. Open **Agency sign-in** in the footer to review the seeded cases and change their statuses. New submissions are stored as non-demo submissions, but they still remain inside this CivicLens deployment until a real authorized integration is implemented.

## Run an end-to-end smoke test

After the app is running and reachable, execute:

```bash
npm run smoke
```

For a remote deployment, set the URL first:

```bash
APP_URL=https://your-domain.example.ng npm run smoke
```

The smoke test checks the health endpoint, positive-match and expired demo verification scenarios, a seeded case lookup, and report submission plus tracking. **It creates one clearly labelled automated test report** in the database each time it runs.

## Main endpoints

- `GET /api/health` — health check
- `GET /api/public/stats` — public summary counts
- `POST /api/verify` — `{ "identifier": "DEMO-NAFDAC-001" }`
- `POST /api/reports` — create a report
- `GET /api/reports/track/:reference` — check status
- `POST /api/admin/login` — admin login
- `GET /api/admin/overview` — protected report dashboard data
- `PATCH /api/admin/reports/:id` — protected status update
- `GET /api/admin/audit` — protected audit log

## Production readiness checklist

This is a working starter, not yet a certified government-grade deployment. Before handling real sensitive reports:

- Replace SQLite with PostgreSQL for multi-user production workloads if required.
- Add agency-level RBAC and strict tenant/agency isolation; the current admin is a single platform-admin role.
- Add MFA, session revocation, CSRF protections for cookie-authenticated mutations, security monitoring, backup/restore testing, and a formal incident-response process.
- Add privacy notice, retention and deletion policy, consent/legal basis review, and secure evidence upload/storage.
- Obtain written authorization and technical documentation for every official data integration.
- Implement real verification adapters only against approved authoritative sources.
- Configure a real email/SMS provider if notifications are required.
- Complete penetration testing and legal/privacy review before real operational use.

## Brand

Working name: CivicLens. Tagline: **Trust. Verification. Public Safety.** Check company-name, trademark, and domain availability before formal launch.
