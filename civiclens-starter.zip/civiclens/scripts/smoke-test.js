'use strict';
const base = (process.env.APP_URL || 'http://127.0.0.1:3000').replace(/\/$/, '');
async function request(path, options = {}) {
  const response = await fetch(`${base}${path}`, {
    ...options,
    headers: { 'content-type': 'application/json', ...(options.headers || {}) }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`${path} returned HTTP ${response.status}: ${body.error || 'request failed'}`);
  return body;
}
(async () => {
  console.log(`CivicLens smoke test against ${base}`);
  const health = await request('/api/health');
  console.log(`✓ health: ${health.name} ${health.version}`);

  const verification = await request('/api/verify', {
    method: 'POST', body: JSON.stringify({ identifier: 'CL-DEMO-NAFDAC-001' })
  });
  if (verification.result !== 'DEMO' || verification.scenarioResult !== 'VERIFIED') {
    throw new Error('Expected the positive-match demo verification scenario.');
  }
  console.log('✓ verification demo: DEMO / VERIFIED scenario');

  const expired = await request('/api/verify', {
    method: 'POST', body: JSON.stringify({ identifier: 'CL-DEMO-NAFDAC-002' })
  });
  if (expired.result !== 'DEMO' || expired.scenarioResult !== 'EXPIRED') {
    throw new Error('Expected the expired demo verification scenario.');
  }
  console.log('✓ verification demo: DEMO / EXPIRED scenario');

  const sampleCase = await request('/api/reports/track/CL-DEMO-2026-002');
  if (!sampleCase.demo || sampleCase.state !== 'Under review') {
    throw new Error('Expected seeded sample case CL-DEMO-2026-002 in Under review state.');
  }
  console.log('✓ report tracking: seeded fictional case');

  const report = await request('/api/reports', {
    method: 'POST',
    body: JSON.stringify({
      category: 'Other',
      title: 'CivicLens automated smoke test',
      description: 'SIMULATION ONLY. Automated smoke test report created to verify the submit and track workflow. Please do not action this as a real report.',
      location: 'Test environment'
    })
  });
  if (!report.reference) throw new Error('Report submission did not return a reference.');
  const tracked = await request(`/api/reports/track/${encodeURIComponent(report.reference)}`);
  if (tracked.reference !== report.reference || tracked.demo) throw new Error('Submitted test report could not be tracked correctly.');
  console.log(`✓ submit and track: ${report.reference}`);
  console.log('All smoke tests passed. Note: the smoke test creates a clearly labelled test report in this database.');
})().catch(error => {
  console.error(`SMOKE TEST FAILED: ${error.message}`);
  process.exitCode = 1;
});
