'use strict';

// DEMO DATA FILE: all seeded verification records and sample reports live here.
// To launch with real sources, set DATA_PROVIDER=live. Do not use these fixtures as official records.

const verificationRows = [
  ['Product registration','CL-DEMO-NAFDAC-001','Amani Vitamin C 500 mg (fictional sample)','VERIFIED','CivicLens demo registry','SIMULATION ONLY: illustrates what a positive match from an authorized regulator source could look like. No real NAFDAC registration is asserted.'],
  ['Product registration','CL-DEMO-NAFDAC-002','GreenField Herbal Tonic (fictional sample)','EXPIRED','CivicLens demo registry','SIMULATION ONLY: illustrates an expired-record response. This is not a real product or regulator record.'],
  ['Product registration','CL-DEMO-NAFDAC-003','QuickRelief Syrup (fictional sample)','INVALID','CivicLens demo registry','SIMULATION ONLY: illustrates an authoritative source reporting an invalid identifier. Do not use this as a real-world product finding.'],
  ['Business registration','CL-DEMO-CAC-001','Northstar Agro Services Ltd. (fictional sample)','VERIFIED','CivicLens demo registry','SIMULATION ONLY: illustrates a matching business record from an authorized registry. This is not a real CAC result.'],
  ['Professional credential','CL-DEMO-PRO-001','Sample Licensed Practitioner (fictional)','UNCONFIRMED','CivicLens demo registry','SIMULATION ONLY: illustrates a record that needs further checking. No real professional credential is represented.'],
  ['Permit / certificate','CL-DEMO-PERMIT-001','Abuja Market Safety Permit (fictional sample)','EXPIRED','CivicLens demo registry','SIMULATION ONLY: fictional permit used to test the expired status. Not issued by any government authority.'],
  ['Public notice','CL-DEMO-NOTICE-001','Sample Public Health Advisory','VERIFIED','CivicLens demo notice board','SIMULATION ONLY: fictional notice for testing source attribution and public-information display.'],
  ['Product registration','CL-DEMO-NAFDAC-004','Sunrise Cooking Oil (fictional sample)','UNCONFIRMED','CivicLens demo registry','SIMULATION ONLY: illustrates an identifier that cannot be confirmed. This is not evidence of fraud or counterfeiting.']
];

const reportRows = [
  ['CL-DEMO-2026-001','Product concern','Unfamiliar product registration on a tonic label','SIMULATION ONLY. A citizen says a fictional herbal tonic label displays a registration number that does not match the example packaging. Test the verification and referral workflow; this is not a real allegation.','Received',null,'Wuse 2, Abuja','-25 hours','-25 hours'],
  ['CL-DEMO-2026-002','Fraud or scam','Fake investment message using a fictional company name','SIMULATION ONLY. A sample message promises guaranteed returns and requests an upfront transfer to a fictional account. Review the report, document evidence, and update the case status.','Under review',null,'Ikeja, Lagos','-2 days','-3 hours'],
  ['CL-DEMO-2026-003','Suspicious activity','Impersonation of a government recruitment page','SIMULATION ONLY. A fictional social media page requests payment for a supposed recruitment form. Test triage and referral handling; no real page or person is identified.','Referred',null,'GRA, Port Harcourt','-3 days','-1 day'],
  ['CL-DEMO-2026-004','Public safety','Damaged streetlight near a school crossing','SIMULATION ONLY. A sample civic report describes a streetlight that is not working near a school crossing. Use this to test assignment and status tracking.','Action required',null,'Independence Layout, Enugu','-4 days','-6 hours'],
  ['CL-DEMO-2026-005','Product concern','Unclear batch and expiry information on packaged drink','SIMULATION ONLY. The fictional package photo is described as having a difficult-to-read batch code. Test evidence review and a request for more information.','Under review',null,'Nassarawa, Kano','-5 days','-2 days'],
  ['CL-DEMO-2026-006','Fraud or scam','SMS claims citizen must pay an agency penalty immediately','SIMULATION ONLY. A mock text message uses urgency and an unverified payment link. Test the fraud-report workflow without opening any link or contacting any real number.','Resolved',null,'Bodija, Ibadan','-7 days','-4 days'],
  ['CL-DEMO-2026-007','Other','Test case for cross-agency referral','SIMULATION ONLY. This fictional case is included to demonstrate a referral from an intake desk to a second authorized team. No actual agency has received this report.','Closed',null,'Garki, Abuja','-10 days','-8 days'],
  ['CL-DEMO-2026-008','Suspicious activity','Unknown caller claims to represent a regulator','SIMULATION ONLY. A fictional caller requests business documents and a fee. Test safe triage, redaction, and guidance to verify directly through official channels.','Received',null,'Kaduna North, Kaduna','-12 hours','-12 hours']
];

function seed(db) {
  const seedVerifications = db.prepare(`INSERT OR IGNORE INTO verifications
    (record_type,identifier,name,status,issuer,note,demo) VALUES (?,?,?,?,?,?,1)`);
  const seedReports = db.prepare(`INSERT OR IGNORE INTO reports
    (reference,category,title,description,state,contact,location,demo,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,1,datetime('now', ?),datetime('now', ?))`);
  db.transaction(() => {
    verificationRows.forEach(row => seedVerifications.run(...row));
    reportRows.forEach(row => seedReports.run(...row));
  })();
}

function verify({ db, identifier }) {
  const record = db.prepare('SELECT record_type,identifier,name,status,issuer,note,demo,updated_at FROM verifications WHERE identifier=? AND demo=1').get(identifier);
  if (!record) return {
    result: 'UNCONFIRMED', identifier,
    message: 'This demo environment cannot confirm that identifier. This is not proof that a record is fake. Check directly with the issuing authority.',
    source: 'CivicLens demo dataset'
  };
  return {
    ...record,
    result: 'DEMO',
    scenarioResult: record.status,
    message: 'DEMONSTRATION DATA ONLY. This fictional scenario is not an official registry result and must not be used for real-world decisions.'
  };
}

module.exports = { name: 'CivicLens demonstration data', seed, verify };
