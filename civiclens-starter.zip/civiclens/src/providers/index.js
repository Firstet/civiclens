'use strict';

// Select the provider through configuration. No app UI changes are required to switch providers.
const mode = String(process.env.DATA_PROVIDER || 'demo').trim().toLowerCase();
if (!['demo', 'live'].includes(mode)) {
  throw new Error(`Unsupported DATA_PROVIDER "${mode}". Use "demo" or "live".`);
}
const adapter = mode === 'demo'
  ? require('./demo-provider')
  : require('./live-provider');

for (const method of ['seed', 'verify']) {
  if (typeof adapter[method] !== 'function') {
    throw new Error(`Data provider ${mode} must export ${method}().`);
  }
}

module.exports = { ...adapter, mode, name: adapter.name || `${mode}-provider` };
