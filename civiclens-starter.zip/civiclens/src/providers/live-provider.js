'use strict';

// LIVE PROVIDER ADAPTER TEMPLATE
// Replace the verify() implementation with the approved API integration for each source.
// Government endpoints, credentials, permitted fields, and data-sharing authorization must be supplied by the relevant institution.
// This safe default never pretends that a live registry was checked.

function seed(_db) {
  // Intentionally does not seed demo verification records or sample cases in live mode.
  // Existing demo rows in an older database remain flagged demo=1 and are hidden from live lookup/admin views.
}

async function verify({ identifier }) {
  const configured = Boolean(process.env.VERIFICATION_API_URL && process.env.VERIFICATION_API_TOKEN);
  if (!configured) {
    return {
      result: 'SOURCE_UNAVAILABLE', identifier,
      name: null,
      issuer: 'No live verification provider configured',
      message: 'Live verification is not configured yet. Connect an authorized official data source before using this feature for real decisions.',
      source: 'No connected official source'
    };
  }

  // Deliberately fail closed until an agency-specific adapter is implemented.
  // Do not send identifiers to a generic endpoint without an agreed request/response contract.
  return {
    result: 'SOURCE_UNAVAILABLE', identifier,
    name: null,
    issuer: 'Live provider adapter requires implementation',
    message: 'Provider credentials are present, but no agency-specific verification adapter has been implemented. No official lookup was performed.',
    source: 'Live provider adapter'
  };
}

module.exports = { name: 'Live provider adapter (not yet connected)', seed, verify };
