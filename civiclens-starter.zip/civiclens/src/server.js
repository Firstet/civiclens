'use strict';
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const JWT_SECRET = process.env.JWT_SECRET || 'development-only-change-this-secret-now';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChangeThisToALongUniquePassword!';
const ADMIN_PASSWORD_HASH = bcrypt.hashSync(ADMIN_PASSWORD, 10);
const isProd = process.env.NODE_ENV === 'production';
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, 'civiclens.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS verifications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, record_type TEXT NOT NULL, identifier TEXT NOT NULL UNIQUE,
 name TEXT NOT NULL, status TEXT NOT NULL, issuer TEXT NOT NULL, note TEXT NOT NULL,
 demo INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reports (
 id INTEGER PRIMARY KEY AUTOINCREMENT, reference TEXT NOT NULL UNIQUE, category TEXT NOT NULL,
 title TEXT NOT NULL, description TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'Received',
 contact TEXT, location TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT NOT NULL, action TEXT NOT NULL,
 entity_type TEXT NOT NULL, entity_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
// Backward-compatible migration for databases created by earlier CivicLens builds.
const reportColumns = db.prepare('PRAGMA table_info(reports)').all().map(c => c.name);
if (!reportColumns.includes('demo')) db.exec('ALTER TABLE reports ADD COLUMN demo INTEGER NOT NULL DEFAULT 0');

// Provider selection isolates demonstration fixtures from live integrations.
// Switch DATA_PROVIDER=live only after configuring and authorizing real data sources.
const provider = require('./providers');
provider.seed(db);

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ["'self'", 'https://fonts.gstatic.com'], scriptSrc: ["'self'", "'unsafe-inline'"], imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"] } } }));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/api/', rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false }));
app.use('/api/reports', rateLimit({ windowMs: 60 * 60 * 1000, limit: 15, standardHeaders: true, legacyHeaders: false }));

function audit(actor, action, entityType, entityId = null) {
 db.prepare('INSERT INTO audit_events(actor,action,entity_type,entity_id) VALUES(?,?,?,?)').run(actor, action, entityType, entityId == null ? null : String(entityId));
}
function requireAdmin(req, res, next) {
 const token = req.cookies.civiclens_session;
 if (!token) return res.status(401).json({ error: 'Sign in to access the agency workspace.' });
 try { req.admin = jwt.verify(token, JWT_SECRET); next(); }
 catch { res.clearCookie('civiclens_session'); return res.status(401).json({ error: 'Session expired. Sign in again.' }); }
}
function clean(value, max = 2000) { return String(value ?? '').trim().slice(0, max); }
function makeRef() { return 'CL-' + new Date().getFullYear() + '-' + require('crypto').randomBytes(4).toString('hex').toUpperCase(); }

app.get('/api/health', (req, res) => res.json({ ok: true, name: 'CivicLens', version: '0.3.0', mode: provider.mode, provider: provider.name, timestamp: new Date().toISOString() }));
app.get('/api/public/stats', (req, res) => {
 const reports = db.prepare("SELECT COUNT(*) AS n FROM reports WHERE demo=0").get().n;
 const verified = db.prepare("SELECT COUNT(*) AS n FROM verifications WHERE demo=0 AND status='VERIFIED'").get().n;
 res.json({ reportsReceived: reports, liveVerifiedRecords: verified, demoRecordsAvailable: provider.mode === 'demo' ? db.prepare('SELECT COUNT(*) AS n FROM verifications WHERE demo=1').get().n : 0, demoReportsAvailable: provider.mode === 'demo' ? db.prepare('SELECT COUNT(*) AS n FROM reports WHERE demo=1').get().n : 0, mode: provider.mode, provider: provider.name });
});

app.post('/api/verify', async (req, res) => {
 const identifier = clean(req.body?.identifier, 120).toUpperCase();
 if (!identifier || identifier.length < 3) return res.status(400).json({ error: 'Enter a valid reference or registration number.' });
 audit('public-anonymous', 'verification_lookup', 'verification', identifier);
 try {
   const result = await provider.verify({ db, identifier });
   res.json({ ...result, identifier, checkedAt: new Date().toISOString(), provider: provider.name });
 } catch (err) {
   console.error('Verification provider error:', err.message);
   res.status(502).json({ result: 'SOURCE_UNAVAILABLE', identifier, message: 'The verification source is currently unavailable. This is not proof that the record is invalid.', checkedAt: new Date().toISOString() });
 }
});

app.post('/api/reports', (req, res) => {
 const category = clean(req.body?.category, 80);
 const title = clean(req.body?.title, 160);
 const description = clean(req.body?.description, 3000);
 const contact = clean(req.body?.contact, 180) || null;
 const location = clean(req.body?.location, 180) || null;
 const allowed = ['Product concern','Fraud or scam','Public safety','Suspicious activity','Other'];
 if (!allowed.includes(category)) return res.status(400).json({ error: 'Choose a valid report category.' });
 if (title.length < 5 || description.length < 20) return res.status(400).json({ error: 'Add a clear title and a description of at least 20 characters.' });
 if (contact && contact.length > 180) return res.status(400).json({ error: 'Contact details are too long.' });
 const reference = makeRef();
 const info = db.prepare('INSERT INTO reports(reference,category,title,description,contact,location,demo) VALUES(?,?,?,?,?,?,0)').run(reference, category, title, description, contact, location);
 audit('public-citizen', 'report_submitted', 'report', info.lastInsertRowid);
 res.status(201).json({ reference, state: 'Received', mode: provider.mode, message: provider.mode === 'demo' ? 'Your report has been recorded in this CivicLens demo deployment. This does not mean an agency has received or accepted it. Keep your reference number to check its status.' : 'Your report has been recorded in this CivicLens deployment only. No government agency integration is connected, so it has not been sent to an agency. Keep your reference number to check its status.' });
});
app.get('/api/reports/track/:reference', (req, res) => {
 const reference = clean(req.params.reference, 40).toUpperCase();
 const r = db.prepare('SELECT reference,category,title,state,created_at,updated_at,demo FROM reports WHERE reference=?').get(reference);
 if (!r || (provider.mode === 'live' && r.demo)) return res.status(404).json({ error: 'No report was found for that reference.' });
 res.json({ ...r, demo: Boolean(r.demo), demoNotice: r.demo ? 'SIMULATION ONLY: this is a fictional seeded case, not a real citizen report.' : null });
});

app.post('/api/admin/login', async (req, res) => {
 const username = clean(req.body?.username, 100);
 const password = String(req.body?.password ?? '');
 const usernameOk = username === ADMIN_USERNAME;
 const passwordOk = password.length > 0 && await bcrypt.compare(password, ADMIN_PASSWORD_HASH);
 if (!usernameOk || !passwordOk) { audit('unknown', 'login_failed', 'session'); return res.status(401).json({ error: 'Incorrect username or password.' }); }
 const token = jwt.sign({ sub: username, role: 'platform_admin' }, JWT_SECRET, { expiresIn: '8h', issuer: 'civiclens' });
 res.cookie('civiclens_session', token, { httpOnly: true, secure: process.env.COOKIE_SECURE === 'true', sameSite: 'strict', maxAge: 8 * 60 * 60 * 1000, path: '/' });
 audit(username, 'login_success', 'session');
 res.json({ ok: true, username, role: 'platform_admin' });
});
app.post('/api/admin/logout', (req, res) => { res.clearCookie('civiclens_session', { path: '/' }); res.json({ ok: true }); });
app.get('/api/admin/me', requireAdmin, (req, res) => res.json({ username: req.admin.sub, role: req.admin.role }));
app.get('/api/admin/overview', requireAdmin, (req, res) => {
 const where = provider.mode === 'live' ? ' WHERE demo=0' : '';
 const total = db.prepare(`SELECT COUNT(*) AS n FROM reports${where}`).get().n;
 const open = db.prepare(`SELECT COUNT(*) AS n FROM reports${where ? where + " AND" : ' WHERE'} state NOT IN ('Resolved','Closed')`).get().n;
 const demo = provider.mode === 'demo' ? db.prepare('SELECT COUNT(*) AS n FROM reports WHERE demo=1').get().n : 0;
 const recent = db.prepare(`SELECT id,reference,category,title,state,location,created_at,demo FROM reports${where} ORDER BY id DESC LIMIT 50`).all();
 const states = db.prepare(`SELECT state,COUNT(*) AS count FROM reports${where} GROUP BY state`).all();
 res.json({ totalReports: total, openReports: open, demoReports: demo, recent, states, provider: provider.name, mode: provider.mode });
});
app.patch('/api/admin/reports/:id', requireAdmin, (req, res) => {
 const id = Number(req.params.id);
 const state = clean(req.body?.state, 40);
 const allowed = ['Received','Under review','Referred','Action required','Resolved','Closed'];
 if (!Number.isInteger(id) || id < 1 || !allowed.includes(state)) return res.status(400).json({ error: 'Invalid report or status.' });
 const result = db.prepare('UPDATE reports SET state=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(state, id);
 if (!result.changes) return res.status(404).json({ error: 'Report not found.' });
 audit(req.admin.sub, 'report_status_changed', 'report', id);
 res.json({ ok: true, id, state });
});
app.get('/api/admin/audit', requireAdmin, (req, res) => res.json(db.prepare('SELECT actor,action,entity_type,entity_id,created_at FROM audit_events ORDER BY id DESC LIMIT 100').all()));

app.get('*', (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: 'Unexpected server error.' }); });

if (isProd && (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32 || ADMIN_PASSWORD.startsWith('ChangeThis'))) {
 console.error('SECURITY CONFIGURATION ERROR: set a unique JWT_SECRET (32+ characters) and a strong ADMIN_PASSWORD in .env before production deployment.');
 process.exit(1);
}
app.listen(PORT, '0.0.0.0', () => console.log(`CivicLens listening on port ${PORT}`));
